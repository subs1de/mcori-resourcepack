# mcori-resourcepack
Minecraft server resource pack for NJU Orienteering Server
